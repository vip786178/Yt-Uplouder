import os

class Config:

    BOT_TOKEN = ""

    SESSION_NAME = ""

    API_ID = "22480303"

    API_HASH = "99c931b6c1ae6f8c3c3e87da173fa424"

    CLIENT_ID = "34500002128-fle7t6mk0onsog8dbn162ou48dh6i2to.apps.googleusercontent.com"

    CLIENT_SECRET = "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"

    AUTH_USERS = [7518770522]

    VIDEO_DESCRIPTION = ""

    VIDEO_CATEGORY = ""

    VIDEO_TITLE_PREFIX = ""

    VIDEO_TITLE_SUFFIX = ""
    
    DEBUG = bool()

    UPLOAD_MODE = "unlisted"
    
    CRED_FILE = "auth_token.txt"